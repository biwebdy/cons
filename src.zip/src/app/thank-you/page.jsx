import ThankYou from "@/components/thankyou/ThankYou";

export const metadata = {
  title: "Expertree | Thank You",
};

export default function page() {
  return (
    <>
      <ThankYou />
    </>
  );
}
