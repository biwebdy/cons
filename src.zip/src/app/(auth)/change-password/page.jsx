import ChangePasswordForm from "@/components/forms/ChangePasswordForm";

export default function ChangePasswordPage() {
  return (
    <ChangePasswordForm />
  );
}