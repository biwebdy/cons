import SignInAdmin from "@/components/forms/SignInAdmin";

export const metadata = {
  title: "Expertree | Log In ",
};

export default function page() {
  return (
    <>
      <SignInAdmin />
    </>
  );
}
