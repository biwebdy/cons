import ForgotPassword from "@/components/forms/ForgotPassword";

export default function page() {
  return (
    <>
      <ForgotPassword />
    </>
  );
}
