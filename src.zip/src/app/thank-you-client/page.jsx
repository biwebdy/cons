import ThankYouClient from "@/components/thankyou/ThankYouClient";

export const metadata = {
  title: "Expertree | Thank You",
};

export default function page() {
  return (
    <>
      <ThankYouClient />
    </>
  );
}
