import SignInAdmin from "@/components/forms/SignInAdmin";

export default function page() {
  return <SignInAdmin />;
}
