import PageNotFound from "@/components/section/PageNotFound";

export default function NotFound() {
  return (
    <>
      <PageNotFound />
    </>
  );
}
