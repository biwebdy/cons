export const nationalityData = [
  {
    option: "Afghanistan",
    value: "Afghanistan",
  },
  {
    option: "Albania",
    value: "Albania",
  },
  {
    option: "Algeria",
    value: "Algeria",
  },
  {
    option: "Andorra",
    value: "Andorra",
  },
  {
    option: "Angola",
    value: "Angola",
  },
  {
    option: "Antigua and Barbuda",
    value: "Antigua and Barbuda",
  },
  {
    option: "Argentina",
    value: "Argentina",
  },
  {
    option: "Armenia",
    value: "Armenia",
  },
  {
    option: "Australia",
    value: "Australia",
  },
  {
    option: "Austria",
    value: "Austria",
  },
  {
    option: "Azerbaijan",
    value: "Azerbaijan",
  },
  {
    option: "Bahamas",
    value: "Bahamas",
  },
  {
    option: "Bahrain",
    value: "Bahrain",
  },
  {
    option: "Bangladesh",
    value: "Bangladesh",
  },
  {
    option: "Barbados",
    value: "Barbados",
  },
  {
    option: "Belarus",
    value: "Belarus",
  },
  {
    option: "Belgium",
    value: "Belgium",
  },
  {
    option: "Belize",
    value: "Belize",
  },
  {
    option: "Benin",
    value: "Benin",
  },
  {
    option: "Bhutan",
    value: "Bhutan",
  },
  {
    option: "Bolivia",
    value: "Bolivia",
  },
  {
    option: "Bosnia and Herzegovina",
    value: "Bosnia and Herzegovina",
  },
  {
    option: "Botswana",
    value: "Botswana",
  },
  {
    option: "Brazil",
    value: "Brazil",
  },
  {
    option: "Brunei",
    value: "Brunei",
  },
  {
    option: "Bulgaria",
    value: "Bulgaria",
  },
  {
    option: "Burkina Faso",
    value: "Burkina Faso",
  },
  {
    option: "Burundi",
    value: "Burundi",
  },
  {
    option: "Cabo Verde",
    value: "Cabo Verde",
  },
  {
    option: "Cambodia",
    value: "Cambodia",
  },
  {
    option: "Cameroon",
    value: "Cameroon",
  },
  {
    option: "Canada",
    value: "Canada",
  },
  {
    option: "Central African Republic",
    value: "Central African Republic",
  },
  {
    option: "Chad",
    value: "Chad",
  },
  {
    option: "Chile",
    value: "Chile",
  },
  {
    option: "China",
    value: "China",
  },
  {
    option: "Colombia",
    value: "Colombia",
  },
  {
    option: "Comoros",
    value: "Comoros",
  },
  {
    option: "Congo",
    value: "Congo",
  },
  {
    option: "Costa Rica",
    value: "Costa Rica",
  },
  {
    option: "Croatia",
    value: "Croatia",
  },
  {
    option: "Cuba",
    value: "Cuba",
  },
  {
    option: "Cyprus",
    value: "Cyprus",
  },
  {
    option: "Czech Republic",
    value: "Czech Republic",
  },
  {
    option: "Denmark",
    value: "Denmark",
  },
  {
    option: "Djibouti",
    value: "Djibouti",
  },
  {
    option: "Dominica",
    value: "Dominica",
  },
  {
    option: "Dominican Republic",
    value: "Dominican Republic",
  },
  {
    option: "Ecuador",
    value: "Ecuador",
  },
  {
    option: "Egypt",
    value: "Egypt",
  },
  {
    option: "El Salvador",
    value: "El Salvador",
  },
  {
    option: "Equatorial Guinea",
    value: "Equatorial Guinea",
  },
  {
    option: "Eritrea",
    value: "Eritrea",
  },
  {
    option: "Estonia",
    value: "Estonia",
  },
  {
    option: "Eswatini",
    value: "Eswatini",
  },
  {
    option: "Ethiopia",
    value: "Ethiopia",
  },
  {
    option: "Fiji",
    value: "Fiji",
  },
  {
    option: "Finland",
    value: "Finland",
  },
  {
    option: "France",
    value: "France",
  },
  {
    option: "Gabon",
    value: "Gabon",
  },
  {
    option: "Gambia",
    value: "Gambia",
  },
  {
    option: "Georgia",
    value: "Georgia",
  },
  {
    option: "Germany",
    value: "Germany",
  },
  {
    option: "Ghana",
    value: "Ghana",
  },
  {
    option: "Greece",
    value: "Greece",
  },
  {
    option: "Grenada",
    value: "Grenada",
  },
  {
    option: "Guatemala",
    value: "Guatemala",
  },
  {
    option: "Guinea",
    value: "Guinea",
  },
  {
    option: "Guinea-Bissau",
    value: "Guinea-Bissau",
  },
  {
    option: "Guyana",
    value: "Guyana",
  },
  {
    option: "Haiti",
    value: "Haiti",
  },
  {
    option: "Honduras",
    value: "Honduras",
  },
  {
    option: "Hungary",
    value: "Hungary",
  },
  {
    option: "Iceland",
    value: "Iceland",
  },
  {
    option: "India",
    value: "India",
  },
  {
    option: "Indonesia",
    value: "Indonesia",
  },
  {
    option: "Iran",
    value: "Iran",
  },
  {
    option: "Iraq",
    value: "Iraq",
  },
  {
    option: "Ireland",
    value: "Ireland",
  },
  {
    option: "Iceland",
    value: "Iceland",
  },
  {
    option: "Iceland",
    value: "Iceland",
  },
  {
    option: "Israel",
    value: "Israel",
  },
  {
    option: "Italy",
    value: "Italy",
  },
  {
    option: "Jamaica",
    value: "Jamaica",
  },
  {
    option: "Japan",
    value: "Japan",
  },
  {
    option: "Jordan",
    value: "Jordan",
  },
  {
    option: "Kazakhstan",
    value: "Kazakhstan",
  },
  {
    option: "Kenya",
    value: "Kenya",
  },
  {
    option: "Kiribati",
    value: "Kiribati",
  },
  {
    option: "Kuwait",
    value: "Kuwait",
  },
  {
    option: "Kyrgyzstan",
    value: "Kyrgyzstan",
  },
  {
    option: "Laos",
    value: "Laos",
  },
  {
    option: "Latvia",
    value: "Latvia",
  },
  {
    option: "Lebanon",
    value: "Lebanon",
  },
  {
    option: "Lesotho",
    value: "Lesotho",
  },
  {
    option: "Liberia",
    value: "Liberia",
  },
  {
    option: "Libya",
    value: "Libya",
  },
  {
    option: "Liechtenstein",
    value: "Liechtenstein",
  },
  {
    option: "Lithuania",
    value: "Lithuania",
  },
  {
    option: "Luxembourg",
    value: "Luxembourg",
  },
  {
    option: "Madagascar",
    value: "Madagascar",
  },
  {
    option: "Malawi",
    value: "Malawi",
  },
  {
    option: "Malaysia",
    value: "Malaysia",
  },
  {
    option: "Maldives",
    value: "Maldives",
  },
  {
    option: "Mali",
    value: "Mali",
  },
  {
    option: "Malta",
    value: "Malta",
  },
  {
    option: "Marshall Islands",
    value: "Marshall Islands",
  },
  {
    option: "Mauritania",
    value: "Mauritania",
  },
  {
    option: "Mauritius",
    value: "Mauritius",
  },
  {
    option: "Mexico",
    value: "Mexico",
  },
  {
    option: "Micronesia",
    value: "Micronesia",
  },
  {
    option: "Moldova",
    value: "Moldova",
  },
  {
    option: "Monaco",
    value: "Monaco",
  },
  {
    option: "Mongolia",
    value: "Mongolia",
  },
  {
    option: "Montenegro",
    value: "Montenegro",
  },
  {
    option: "Morocco",
    value: "Morocco",
  },
  {
    option: "Mozambique",
    value: "Mozambique",
  },
  {
    option: "Myanmar",
    value: "Myanmar",
  },
  {
    option: "Namibia",
    value: "Namibia",
  },
  {
    option: "Nauru",
    value: "Nauru",
  },
  {
    option: "Nepal",
    value: "Nepal",
  },
  {
    option: "Netherlands",
    value: "Netherlands",
  },
  {
    option: "New Zealand",
    value: "New Zealand",
  },
  {
    option: "Nicaragua",
    value: "Nicaragua",
  },
  {
    option: "Niger",
    value: "Niger",
  },
  {
    option: "Nigeria",
    value: "Nigeria",
  },
  {
    option: "North Korea",
    value: "North Korea",
  },
  {
    option: "North Macedonia",
    value: "North Macedonia",
  },
  {
    option: "Norway",
    value: "Norway",
  },
  {
    option: "Oman",
    value: "Oman",
  },
  {
    option: "Pakistan",
    value: "Pakistan",
  },
  {
    option: "Palau",
    value: "Palau",
  },
  {
    option: "Palestine",
    value: "Palestine",
  },
  {
    option: "Panama",
    value: "Panama",
  },
  {
    option: "Papua New Guinea",
    value: "Papua New Guinea",
  },
  {
    option: "Paraguay",
    value: "Paraguay",
  },
  {
    option: "Peru",
    value: "Peru",
  },
  {
    option: "Philippines",
    value: "Philippines",
  },
  {
    option: "Poland",
    value: "Poland",
  },
  {
    option: "Portugal",
    value: "Portugal",
  },
  {
    option: "Qatar",
    value: "Qatar",
  },
  {
    option: "Romania",
    value: "Romania",
  },
  {
    option: "Russia",
    value: "Russia",
  },
  {
    option: "Rwanda",
    value: "Rwanda",
  },
  {
    option: "Saint Kitts and Nevis",
    value: "Saint Kitts and Nevis",
  },
  {
    option: "Saint Lucia",
    value: "Saint Lucia",
  },
  {
    option: "Saint Vincent and the Grenadines",
    value: "Saint Vincent and the Grenadines",
  },
  {
    option: "Samoa",
    value: "Samoa",
  },
  {
    option: "San Marino",
    value: "San Marino",
  },
  {
    option: "Sao Tome and Principe",
    value: "Sao Tome and Principe",
  },
  {
    option: "Saudi Arabia",
    value: "Saudi Arabia",
  },
  {
    option: "Senegal",
    value: "Senegal",
  },
  {
    option: "Serbia",
    value: "Serbia",
  },
  {
    option: "Seychelles",
    value: "Seychelles",
  },
  {
    option: "Sierra Leone",
    value: "Sierra Leone",
  },
  {
    option: "Singapore",
    value: "Singapore",
  },
  {
    option: "Slovakia",
    value: "Slovakia",
  },
  {
    option: "Slovenia",
    value: "Slovenia",
  },
  {
    option: "Solomon Islands",
    value: "Solomon Islands",
  },
  {
    option: "Somalia",
    value: "Somalia",
  },
  {
    option: "South Africa",
    value: "South Africa",
  },
  {
    option: "South Korea",
    value: "South Korea",
  },
  {
    option: "South Sudan",
    value: "South Sudan",
  },
  {
    option: "Spain",
    value: "Spain",
  },
  {
    option: "Sri Lanka",
    value: "Sri Lanka",
  },
  {
    option: "Sudan",
    value: "Sudan",
  },
  {
    option: "Suriname",
    value: "Suriname",
  },
  {
    option: "Sweden",
    value: "Sweden",
  },
  {
    option: "Switzerland",
    value: "Switzerland",
  },
  {
    option: "Syria",
    value: "Syria",
  },
  {
    option: "Taiwan",
    value: "Taiwan",
  },
  {
    option: "Tajikistan",
    value: "Tajikistan",
  },
  {
    option: "Tanzania",
    value: "Tanzania",
  },
  {
    option: "Thailand",
    value: "Thailand",
  },
  {
    option: "Timor-Leste",
    value: "Timor-Leste",
  },
  {
    option: "Togo",
    value: "Togo",
  },
  {
    option: "Tonga",
    value: "Tonga",
  },
  {
    option: "Trinidad and Tobago",
    value: "Trinidad and Tobago",
  },
  {
    option: "Tunisia",
    value: "Tunisia",
  },
  {
    option: "Turkey",
    value: "Turkey",
  },
  {
    option: "Turkmenistan",
    value: "Turkmenistan",
  },
  {
    option: "Tuvalu",
    value: "Tuvalu",
  },
  {
    option: "Uganda",
    value: "Uganda",
  },
  {
    option: "Ukraine",
    value: "Ukraine",
  },
  {
    option: "United Arab Emirates",
    value: "United Arab Emirates",
  },
  {
    option: "United Kingdom",
    value: "United Kingdom",
  },
  {
    option: "United States",
    value: "United States",
  },
  {
    option: "Uruguay",
    value: "Uruguay",
  },
  {
    option: "Uzbekistan",
    value: "Uzbekistan",
  },
  {
    option: "Vanuatu",
    value: "Vanuatu",
  },
  {
    option: "Vatican City",
    value: "Vatican City",
  },
  {
    option: "Venezuela",
    value: "Venezuela",
  },
  {
    option: "Vietnam",
    value: "Vietnam",
  },
  {
    option: "Yemen",
    value: "Yemen",
  },
  {
    option: "Zambia",
    value: "Zambia",
  },
  {
    option: "Zimbabwe",
    value: "Zimbabwe",
  },
];
